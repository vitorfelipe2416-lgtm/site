/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { WhatsAppModal } from './components/WhatsAppModal';

export default function App() {
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string | undefined>(undefined);

  const handleOpenQuote = (serviceName?: string) => {
    setSelectedService(serviceName);
    setQuoteModalOpen(true);
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-white text-[#070B12]">
        <Navbar onOpenQuote={handleOpenQuote} />

        <main className="flex-1">
          <HeroSection onOpenQuote={handleOpenQuote} />
          <AboutSection onOpenQuote={handleOpenQuote} />
          <ServicesSection onOpenQuote={handleOpenQuote} />
          <PortfolioSection onOpenQuote={handleOpenQuote} />
          <TestimonialsSection />
          <ContactSection />
        </main>

        <Footer onOpenQuote={handleOpenQuote} />
        <FloatingWhatsApp onOpenQuote={handleOpenQuote} />
        <WhatsAppModal
          isOpen={quoteModalOpen}
          initialService={selectedService}
          onClose={() => setQuoteModalOpen(false)}
        />
      </div>
    </MotionConfig>
  );
}
