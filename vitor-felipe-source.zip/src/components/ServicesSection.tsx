import { motion } from 'motion/react';
import { ArrowUpRight, Check } from 'lucide-react';
import { SERVICES } from '../data/portfolioData';
import { WhatsAppIcon } from './WhatsAppIcon';

interface ServicesSectionProps {
  onOpenQuote: (serviceName?: string) => void;
}

export function ServicesSection({ onOpenQuote }: ServicesSectionProps) {
  return (
    <section id="servicos" className="bg-[#060B14] text-white py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-12 border-b border-white/15">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-slate-300 tracking-wide mb-3">
              Serviços · Soluções sob medida
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white text-balance">
              O formato certo para o momento atual do seu negócio.
            </h2>
          </div>

          <p className="text-sm sm:text-base text-slate-300 max-w-md leading-relaxed">
            Todos os projetos incluem versão responsiva para celular, configuração de SEO técnico e integração direta para atendimento no WhatsApp.
          </p>
        </div>

        {/* Asymmetric bento grid of numbered services */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {SERVICES.map((service, index) => {
            const isPrimary = service.featured;
            return (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.4, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] }}
                className={`rounded-2xl border p-7 sm:p-8 flex flex-col justify-between transition-colors duration-150 ${
                  isPrimary
                    ? 'lg:col-span-7 bg-[#0B1F3A] border-white/20'
                    : 'lg:col-span-5 bg-[#0A1322] border-white/12 hover:border-white/25'
                } ${index === 2 ? 'lg:col-span-5' : ''} ${index === 3 ? 'lg:col-span-7' : ''}`}
              >
                <div>
                  <div className="flex items-center justify-between gap-4 mb-5">
                    <span className="font-mono text-sm font-medium text-slate-300 tabular-nums">
                      {service.number}
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      {service.timeline}
                    </span>
                  </div>

                  <h3 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white mb-2">
                    {service.title}
                  </h3>

                  <p className="text-sm font-medium text-slate-200 mb-4">
                    {service.subtitle}
                  </p>

                  <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  <ul className="space-y-2.5 mb-8">
                    {service.deliverables.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm text-slate-200">
                        <Check className="w-4 h-4 text-white shrink-0 mt-0.5" strokeWidth={2} />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-5 border-t border-white/12 flex items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={() => onOpenQuote(service.title)}
                    className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] rounded-lg text-sm font-semibold transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${
                      isPrimary
                        ? 'bg-white text-[#060B14] hover:bg-slate-100'
                        : 'bg-white/10 text-white hover:bg-white hover:text-[#060B14] border border-white/20'
                    }`}
                  >
                    <WhatsAppIcon className="w-4 h-4 shrink-0" />
                    <span>Solicitar orçamento no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
