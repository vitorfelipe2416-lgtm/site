import { motion } from 'motion/react';
import { ArrowDownRight } from 'lucide-react';
import { HERO_IMAGE, HERO_METRICS } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';
import { WhatsAppIcon } from './WhatsAppIcon';

interface HeroSectionProps {
  onOpenQuote: (serviceName?: string) => void;
}

export function HeroSection({ onOpenQuote }: HeroSectionProps) {
  return (
    <section id="inicio" className="bg-white pt-10 pb-16 sm:pt-14 sm:pb-24 border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split-screen hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-between py-2"
          >
            <div>
              <p className="text-xs sm:text-sm font-medium text-slate-600 mb-5">
                Criação de sites sob medida · Atendimento remoto
              </p>

              <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.35rem] font-bold tracking-tight text-[#070B12] leading-[1.08] text-balance mb-6">
                Sites rápidos e estratégicos que transformam visitas em orçamentos.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl mb-8">
                Projeto e desenvolvo sites institucionais, landing pages e portfólios com visual limpo, carregamento instantâneo no celular e foco total em levar seu cliente direto para o WhatsApp.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <button
                type="button"
                onClick={() => onOpenQuote()}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 min-h-[48px] rounded-lg bg-[#0B1F3A] text-white text-sm sm:text-base font-semibold hover:bg-[#112D54] active:scale-[0.99] transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
              >
                <WhatsAppIcon className="w-4 h-4 shrink-0" />
                <span>Solicitar orçamento no WhatsApp</span>
              </button>

              <a
                href="#projetos"
                className="inline-flex items-center justify-center sm:justify-start gap-1.5 px-3 py-3 min-h-[44px] text-sm font-medium text-[#070B12] hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 group focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
              >
                <span>Ver projetos selecionados</span>
                <ArrowDownRight className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:translate-y-0.5" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex"
          >
            <div className="w-full overflow-hidden rounded-2xl border border-slate-200 bg-[#F7F9FC]">
              <ResilientImage
                src={HERO_IMAGE.src}
                alt={HERO_IMAGE.alt}
                title="Vitor Felipe — Criação de Sites"
                aspectClassName="aspect-[16/10] lg:h-full"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* Full-width 4-column proof/metric strip below hero split */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.14, ease: [0.16, 1, 0.3, 1] }}
          className="mt-12 sm:mt-16 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8"
        >
          {HERO_METRICS.map((metric) => (
            <div key={metric.label} className="space-y-1">
              <div className="font-mono text-2xl sm:text-3xl font-semibold tracking-tight text-[#0B1F3A] tabular-nums">
                {metric.value}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-snug">
                {metric.label}
              </p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
