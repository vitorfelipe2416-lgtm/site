import { WHATSAPP_DISPLAY, buildWhatsAppUrl } from '../data/portfolioData';
import { WhatsAppIcon } from './WhatsAppIcon';

interface FooterProps {
  onOpenQuote: (serviceName?: string) => void;
}

export function Footer({ onOpenQuote }: FooterProps) {
  return (
    <footer className="bg-[#05080F] text-white border-t border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-10 border-b border-white/10">
          <div className="space-y-2">
            <a
              href="#inicio"
              className="font-display text-2xl font-bold tracking-tight text-white inline-block"
            >
              Vitor Felipe
            </a>
            <p className="text-sm text-slate-300 max-w-sm">
              Criação de sites sob medida, rápidos e orientados à geração de orçamentos no WhatsApp.
            </p>
            <a
              href={buildWhatsAppUrl({})}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm font-medium text-white/90 hover:text-white transition-colors pt-1"
            >
              <WhatsAppIcon className="w-4 h-4 shrink-0" />
              <span className="tabular-nums">{WHATSAPP_DISPLAY}</span>
            </a>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-6">
            <nav aria-label="Links do rodapé" className="flex flex-wrap items-center gap-6 text-sm text-slate-300">
              <a href="#sobre" className="hover:text-white transition-colors whitespace-nowrap">
                Sobre
              </a>
              <a href="#servicos" className="hover:text-white transition-colors whitespace-nowrap">
                Serviços
              </a>
              <a href="#projetos" className="hover:text-white transition-colors whitespace-nowrap">
                Projetos
              </a>
              <a href="#depoimentos" className="hover:text-white transition-colors whitespace-nowrap">
                Depoimentos
              </a>
              <a href="#contato" className="hover:text-white transition-colors whitespace-nowrap">
                Contato
              </a>
            </nav>

            <button
              type="button"
              onClick={() => onOpenQuote()}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] rounded-lg bg-white text-[#05080F] text-sm font-semibold hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <WhatsAppIcon className="w-4 h-4 shrink-0" />
              <span>Solicitar orçamento no WhatsApp</span>
            </button>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} Vitor Felipe. Todos os direitos reservados.</p>
          <p>Atendimento remoto para todo o Brasil.</p>
        </div>
      </div>
    </footer>
  );
}
