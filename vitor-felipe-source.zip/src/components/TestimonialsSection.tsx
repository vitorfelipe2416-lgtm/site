import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/portfolioData';

export function TestimonialsSection() {
  return (
    <section id="depoimentos" className="bg-[#F7F9FC] py-20 sm:py-28 border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-medium text-[#0B1F3A] mb-3">
            Depoimentos · Retorno comprovado
          </p>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070B12] text-balance">
            O impacto do novo site na rotina comercial de quem já contratou.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item, index) => (
            <motion.figure
              key={item.id}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white rounded-2xl border border-slate-200 p-7 flex flex-col justify-between"
            >
              <div>
                <p className="text-xs font-semibold text-[#0B1F3A] mb-4">
                  {item.outcome}
                </p>
                <blockquote className="text-sm sm:text-base text-[#070B12] leading-relaxed mb-8">
                  “{item.quote}”
                </blockquote>
              </div>

              <figcaption className="pt-5 border-t border-slate-200">
                <div className="font-display text-sm font-semibold text-[#070B12]">
                  {item.name}
                </div>
                <div className="text-xs text-slate-600 mt-0.5">
                  {item.role} · {item.company}
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
