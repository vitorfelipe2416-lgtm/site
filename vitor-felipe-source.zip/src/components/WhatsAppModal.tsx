import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Check, Copy, X } from 'lucide-react';
import {
  SERVICES,
  WHATSAPP_DISPLAY,
  buildWhatsAppMessage,
  buildWhatsAppUrl,
} from '../data/portfolioData';
import { WhatsAppIcon } from './WhatsAppIcon';

interface WhatsAppModalProps {
  isOpen: boolean;
  initialService?: string;
  onClose: () => void;
}

export function WhatsAppModal({
  isOpen,
  initialService,
  onClose,
}: WhatsAppModalProps) {
  const [name, setName] = useState('');
  const [business, setBusiness] = useState('');
  const [service, setService] = useState(initialService || SERVICES[0].title);
  const [objective, setObjective] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (initialService) {
      setService(initialService);
    }
  }, [initialService]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  const payload = { name, business, service, objective };
  const whatsappUrl = buildWhatsAppUrl(payload);
  const previewText = buildWhatsAppMessage(payload);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(previewText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 bg-[#05080F]/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-labelledby="whatsapp-modal-title"
        >
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full overflow-hidden shadow-2xl my-auto"
          >
            <div className="bg-[#0B1F3A] text-white px-6 py-5 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-medium text-slate-300 mb-1">
                  Atendimento direto com Vitor Felipe · {WHATSAPP_DISPLAY}
                </p>
                <h3
                  id="whatsapp-modal-title"
                  className="font-display text-xl font-bold tracking-tight"
                >
                  Solicitar orçamento no WhatsApp
                </h3>
              </div>

              <button
                type="button"
                onClick={onClose}
                aria-label="Fechar janela de orçamento"
                className="inline-flex items-center justify-center w-9 h-9 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="modal-name"
                    className="block text-xs font-medium text-[#070B12] mb-1.5"
                  >
                    Seu nome
                  </label>
                  <input
                    id="modal-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex.: Lucas Ferreira"
                    className="w-full px-3.5 py-2.5 min-h-[42px] rounded-lg border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15"
                  />
                </div>

                <div>
                  <label
                    htmlFor="modal-business"
                    className="block text-xs font-medium text-[#070B12] mb-1.5"
                  >
                    Empresa / Nicho
                  </label>
                  <input
                    id="modal-business"
                    type="text"
                    value={business}
                    onChange={(e) => setBusiness(e.target.value)}
                    placeholder="Ex.: Escritório contábil"
                    className="w-full px-3.5 py-2.5 min-h-[42px] rounded-lg border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="modal-service"
                  className="block text-xs font-medium text-[#070B12] mb-1.5"
                >
                  O que você precisa?
                </label>
                <select
                  id="modal-service"
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full px-3.5 py-2.5 min-h-[42px] rounded-lg border border-slate-300 text-sm text-[#070B12] bg-white focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15"
                >
                  {SERVICES.map((item) => (
                    <option key={item.id} value={item.title}>
                      {item.title}
                    </option>
                  ))}
                  {initialService &&
                    !SERVICES.some((item) => item.title === initialService) && (
                      <option value={initialService}>{initialService}</option>
                    )}
                  <option value="Outro projeto sob medida">Outro projeto sob medida</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="modal-objective"
                  className="block text-xs font-medium text-[#070B12] mb-1.5"
                >
                  Resumo rápido (opcional)
                </label>
                <textarea
                  id="modal-objective"
                  rows={2}
                  value={objective}
                  onChange={(e) => setObjective(e.target.value)}
                  placeholder="Ex.: Quero lançar uma página para divulgar meus serviços no Google."
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 resize-none"
                />
              </div>

              <div className="rounded-xl bg-[#F7F9FC] border border-slate-200 p-3.5">
                <div className="text-[11px] font-medium text-slate-600 mb-1.5">
                  Mensagem preparada para o WhatsApp:
                </div>
                <p className="text-xs text-[#070B12] whitespace-pre-wrap leading-relaxed">
                  {previewText}
                </p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 min-h-[46px] rounded-lg bg-[#0B1F3A] text-white text-sm font-semibold hover:bg-[#112D54] transition-colors whitespace-nowrap"
                >
                  <WhatsAppIcon className="w-4 h-4 shrink-0" />
                  <span>Solicitar orçamento no WhatsApp</span>
                </a>

                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-3 min-h-[46px] rounded-lg border border-slate-300 bg-white text-sm font-medium text-[#070B12] hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-[#0B1F3A]" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                  <span>{copied ? 'Copiado' : 'Copiar'}</span>
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
