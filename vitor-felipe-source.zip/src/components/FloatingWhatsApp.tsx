import { WhatsAppIcon } from './WhatsAppIcon';

interface FloatingWhatsAppProps {
  onOpenQuote: (serviceName?: string) => void;
}

export function FloatingWhatsApp({ onOpenQuote }: FloatingWhatsAppProps) {
  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40">
      <button
        type="button"
        onClick={() => onOpenQuote()}
        aria-label="Solicitar orçamento no WhatsApp"
        className="inline-flex items-center gap-2.5 px-4 py-3 min-h-[48px] rounded-full bg-[#0B1F3A] text-white text-sm font-semibold shadow-lg border border-white/15 hover:bg-[#112D54] active:scale-[0.97] transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
      >
        <WhatsAppIcon className="w-5 h-5 shrink-0" />
        <span className="hidden sm:inline">Orçamento no WhatsApp</span>
      </button>
    </div>
  );
}
