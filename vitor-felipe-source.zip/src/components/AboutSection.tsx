import { motion } from 'motion/react';
import { ABOUT_IMAGE, DIFFERENTIALS } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';
import { WhatsAppIcon } from './WhatsAppIcon';

interface AboutSectionProps {
  onOpenQuote: (serviceName?: string) => void;
}

export function AboutSection({ onOpenQuote }: AboutSectionProps) {
  return (
    <section id="sobre" className="bg-[#F7F9FC] py-20 sm:py-28 border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-stretch">
          {/* Portrait visual */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex"
          >
            <div className="w-full overflow-hidden rounded-2xl border border-slate-200 bg-white">
              <ResilientImage
                src={ABOUT_IMAGE.src}
                alt={ABOUT_IMAGE.alt}
                title="Vitor Felipe — Web Designer e Desenvolvedor"
                aspectClassName="aspect-[3/4] lg:h-full"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Editorial bio + 4 competitive differentials */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-between"
          >
            <div>
              <p className="text-xs font-medium text-[#0B1F3A] mb-3">
                Sobre · Quem projeta o seu site
              </p>

              <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070B12] text-balance mb-5">
                Menos enfeite. Mais clareza, velocidade e resultado comercial.
              </h2>

              <div className="space-y-4 text-base text-slate-600 leading-relaxed mb-10 max-w-2xl">
                <p>
                  Sou o <strong className="font-semibold text-[#070B12]">Vitor Felipe</strong>, profissional autônomo especializado na criação de sites sob medida para empresas, clínicas, consultorias e prestadores de serviço.
                </p>
                <p>
                  Muitos negócios perdem clientes todos os dias porque dependem apenas de redes sociais ou usam sites lentos e genéricos. Meu trabalho une design minimalista, texto persuasivo e código limpo para que o visitante entenda o seu valor em segundos e dê o próximo passo no WhatsApp.
                </p>
              </div>
            </div>

            {/* 2x2 Differentials grid with clean hairline borders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {DIFFERENTIALS.map((item) => (
                <div
                  key={item.number}
                  className="bg-white rounded-xl border border-slate-200 p-5"
                >
                  <div className="font-mono text-xs font-medium text-[#0B1F3A] tabular-nums mb-2">
                    {item.number}
                  </div>
                  <h3 className="font-display text-base font-semibold text-[#070B12] mb-1.5">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            <div>
              <button
                type="button"
                onClick={() => onOpenQuote()}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-[44px] rounded-lg bg-[#0B1F3A] text-white text-sm font-semibold hover:bg-[#112D54] active:scale-[0.99] transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
              >
                <WhatsAppIcon className="w-4 h-4 shrink-0" />
                <span>Solicitar orçamento no WhatsApp</span>
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
