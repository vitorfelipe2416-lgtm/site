import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, X } from 'lucide-react';
import { PROJECTS, ProjectCategory, ProjectItem } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';
import { WhatsAppIcon } from './WhatsAppIcon';

interface PortfolioSectionProps {
  onOpenQuote: (serviceName?: string) => void;
}

const CATEGORIES: ProjectCategory[] = ['Todos', 'Institucional', 'Landing Page', 'Portfólio'];

export function PortfolioSection({ onOpenQuote }: PortfolioSectionProps) {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('Todos');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const filteredProjects =
    activeCategory === 'Todos'
      ? PROJECTS
      : PROJECTS.filter((project) => project.category === activeCategory);

  useEffect(() => {
    if (!selectedProject) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section id="projetos" className="bg-white py-20 sm:py-28 border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header + functional filter tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-xl">
            <p className="text-xs font-medium text-[#0B1F3A] mb-3">
              Portfólio · Projetos selecionados
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070B12] text-balance">
              Sites publicados com foco em posicionamento e conversão real.
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar projetos por categoria"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-[#F1F5F9] rounded-lg self-start md:self-auto"
          >
            {CATEGORIES.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(category)}
                  className={`px-3.5 py-2 min-h-[36px] text-xs sm:text-sm font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[#0B1F3A] ${
                    isActive
                      ? 'bg-white text-[#070B12] shadow-xs'
                      : 'text-slate-600 hover:text-[#070B12]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Media-first asymmetric Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {filteredProjects.map((project, index) => {
            const isHeroTile = activeCategory === 'Todos' && index === 0;
            return (
              <motion.article
                key={project.id}
                layout
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className={`group rounded-2xl border border-slate-200 bg-white overflow-hidden flex flex-col justify-between transition-colors duration-150 hover:border-[#0B1F3A]/40 ${
                  isHeroTile ? 'lg:col-span-12 lg:grid lg:grid-cols-12' : 'lg:col-span-6'
                }`}
              >
                <div className={isHeroTile ? 'lg:col-span-7 overflow-hidden bg-[#F7F9FC]' : 'overflow-hidden bg-[#F7F9FC]'}>
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    className="w-full h-full block text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-[#0B1F3A]"
                    aria-label={`Ver detalhes do projeto ${project.title}`}
                  >
                    <ResilientImage
                      src={project.image}
                      alt={project.imageAlt}
                      title={project.title}
                      aspectClassName={isHeroTile ? 'aspect-[16/10] lg:h-full' : 'aspect-[4/3]'}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  </button>
                </div>

                <div className={`p-6 sm:p-8 flex flex-col justify-between ${isHeroTile ? 'lg:col-span-5' : ''}`}>
                  <div>
                    {/* Zero-pill unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 mb-3">
                      <span className="font-medium text-[#0B1F3A]">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{project.year}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.client}</span>
                    </div>

                    <h3 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#070B12] mb-2">
                      {project.title}
                    </h3>

                    <p className="text-sm font-semibold text-[#0B1F3A] mb-3">
                      {project.outcome}
                    </p>

                    <p className="text-sm text-slate-600 leading-relaxed mb-6">
                      {project.summary}
                    </p>
                  </div>

                  <div className="pt-5 border-t border-slate-200 flex items-center justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="inline-flex items-center gap-1.5 py-2 text-sm font-semibold text-[#070B12] hover:text-[#0B1F3A] transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
                    >
                      <span>Ver estudo de caso</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenQuote(`Site similar ao projeto ${project.client}`)}
                      className="text-xs font-medium text-slate-600 hover:text-[#0B1F3A] underline underline-offset-4 whitespace-nowrap cursor-pointer"
                    >
                      Quero um site assim
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Case Study Lightbox Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 bg-[#05080F]/80 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
            onClick={() => setSelectedProject(null)}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-project-title"
          >
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.98 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full overflow-hidden my-auto shadow-2xl"
            >
              <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-200">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <span className="font-semibold text-[#0B1F3A]">{selectedProject.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.client}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{selectedProject.year}</span>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  aria-label="Fechar estudo de caso"
                  className="inline-flex items-center justify-center w-9 h-9 rounded-lg text-slate-600 hover:text-[#070B12] hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="max-h-[80vh] overflow-y-auto">
                <div className="bg-[#F7F9FC] border-b border-slate-200">
                  <ResilientImage
                    src={selectedProject.image}
                    alt={selectedProject.imageAlt}
                    title={selectedProject.title}
                    aspectClassName="aspect-[16/9]"
                    className="w-full h-full object-cover max-h-[360px]"
                  />
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  <div>
                    <h3
                      id="modal-project-title"
                      className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#070B12] mb-2"
                    >
                      {selectedProject.title}
                    </h3>
                    <p className="text-sm sm:text-base font-semibold text-[#0B1F3A]">
                      {selectedProject.outcome}
                    </p>
                  </div>

                  {/* Quantitative metrics */}
                  <div className="grid grid-cols-3 gap-4 py-4 border-y border-slate-200">
                    {selectedProject.metrics.map((m) => (
                      <div key={m.label}>
                        <div className="font-mono text-lg sm:text-2xl font-bold text-[#070B12] tabular-nums">
                          {m.value}
                        </div>
                        <div className="text-xs text-slate-600 mt-0.5">{m.label}</div>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-display text-sm font-semibold text-[#070B12] mb-1.5">
                        Cenário inicial
                      </h4>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {selectedProject.challenge}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-display text-sm font-semibold text-[#070B12] mb-1.5">
                        O que foi implementado
                      </h4>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {selectedProject.solution}
                      </p>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600">
                    <span className="font-semibold text-[#070B12]">Entregas: </span>
                    {selectedProject.deliverables.join(' · ')}
                  </div>

                  <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <button
                      type="button"
                      onClick={() => {
                        const projectClient = selectedProject.client;
                        setSelectedProject(null);
                        onOpenQuote(`Projeto semelhante a ${projectClient}`);
                      }}
                      className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#0B1F3A] text-white text-sm font-semibold hover:bg-[#112D54] transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <WhatsAppIcon className="w-4 h-4 shrink-0" />
                      <span>Solicitar orçamento no WhatsApp</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedProject(null)}
                      className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-[#070B12] cursor-pointer"
                    >
                      Voltar aos projetos
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
