import { FormEvent, useState } from 'react';
import { motion } from 'motion/react';
import { Check, Copy, RotateCcw } from 'lucide-react';
import {
  SERVICES,
  WHATSAPP_DISPLAY,
  buildWhatsAppMessage,
  buildWhatsAppUrl,
} from '../data/portfolioData';
import { WhatsAppIcon } from './WhatsAppIcon';

interface FormErrors {
  name?: string;
  contact?: string;
  objective?: string;
}

export function ContactSection() {
  const [name, setName] = useState('');
  const [business, setBusiness] = useState('');
  const [service, setService] = useState(SERVICES[0].title);
  const [contact, setContact] = useState('');
  const [objective, setObjective] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    const cleanContact = contact.trim();
    const looksLikeEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanContact);
    const looksLikePhone = cleanContact.replace(/\D/g, '').length >= 8;
    if (!looksLikeEmail && !looksLikePhone) {
      nextErrors.contact = 'Informe um WhatsApp (com DDD) ou e-mail válido.';
    }
    if (objective.trim().length < 10) {
      nextErrors.objective = 'Descreva brevemente o que você precisa no site.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
  };

  const payload = { name, business, service, objective, contact };
  const whatsappUrl = buildWhatsAppUrl(payload);
  const whatsappMessage = buildWhatsAppMessage(payload);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setCopied(false);
  };

  return (
    <section id="contato" className="bg-white py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left column: Value & process clarity */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs font-medium text-[#0B1F3A] mb-3">
              Contato · Solicite seu orçamento
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#070B12] text-balance mb-5">
              Vamos tirar seu novo site do papel com prazo e escopo claros.
            </h2>
            <p className="text-base text-slate-600 leading-relaxed mb-8">
              Preencha os campos ao lado para gerar seu resumo de projeto e iniciar o atendimento diretamente no WhatsApp. Sem compromisso e sem formulários intermináveis.
            </p>

            <div className="space-y-5 pt-6 border-t border-slate-200">
              <div>
                <div className="font-mono text-xs font-medium text-[#0B1F3A] tabular-nums mb-1">
                  01. Diagnóstico rápido
                </div>
                <p className="text-sm text-slate-600">
                  Entendo seu público, sua oferta e o que precisa estar em destaque na primeira dobra.
                </p>
              </div>
              <div>
                <div className="font-mono text-xs font-medium text-[#0B1F3A] tabular-nums mb-1">
                  02. Proposta objetiva em até 24h
                </div>
                <p className="text-sm text-slate-600">
                  Você recebe valor fechado, cronograma de entrega e etapas de aprovação por WhatsApp.
                </p>
              </div>
              <div>
                <div className="font-mono text-xs font-medium text-[#0B1F3A] tabular-nums mb-1">
                  03. Publicação pronta para converter
                </div>
                <p className="text-sm text-slate-600">
                  Entrega configurada com domínio, certificado seguro, velocidade mobile e botões de contato.
                </p>
              </div>
              <div className="pt-2">
                <a
                  href={buildWhatsAppUrl({})}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#0B1F3A] hover:text-[#112D54] underline underline-offset-4"
                >
                  <WhatsAppIcon className="w-4 h-4 shrink-0" />
                  <span>WhatsApp direto: {WHATSAPP_DISPLAY}</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right column: Validated form or WhatsApp dispatch summary */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="rounded-2xl border border-slate-200 bg-[#F7F9FC] p-6 sm:p-10">
              {!submitted ? (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-sm font-medium text-[#070B12] mb-1.5"
                      >
                        Seu nome *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                        }}
                        placeholder="Ex.: Mariana Costa"
                        aria-invalid={Boolean(errors.name)}
                        className="w-full px-4 py-3 min-h-[44px] rounded-lg bg-white border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 transition-colors"
                      />
                      {errors.name && (
                        <p className="mt-1.5 text-xs font-medium text-red-700" role="alert">
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-business"
                        className="block text-sm font-medium text-[#070B12] mb-1.5"
                      >
                        Empresa ou segmento
                      </label>
                      <input
                        id="contact-business"
                        type="text"
                        value={business}
                        onChange={(e) => setBusiness(e.target.value)}
                        placeholder="Ex.: Clínica odontológica, Advocacia..."
                        className="w-full px-4 py-3 min-h-[44px] rounded-lg bg-white border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="contact-service"
                        className="block text-sm font-medium text-[#070B12] mb-1.5"
                      >
                        Tipo de projeto
                      </label>
                      <select
                        id="contact-service"
                        value={service}
                        onChange={(e) => setService(e.target.value)}
                        className="w-full px-4 py-3 min-h-[44px] rounded-lg bg-white border border-slate-300 text-sm text-[#070B12] focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 transition-colors"
                      >
                        {SERVICES.map((item) => (
                          <option key={item.id} value={item.title}>
                            {item.title}
                          </option>
                        ))}
                        <option value="Outro projeto sob medida">Outro projeto sob medida</option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-info"
                        className="block text-sm font-medium text-[#070B12] mb-1.5"
                      >
                        WhatsApp ou e-mail para retorno *
                      </label>
                      <input
                        id="contact-info"
                        type="text"
                        value={contact}
                        onChange={(e) => {
                          setContact(e.target.value);
                          if (errors.contact) setErrors((prev) => ({ ...prev, contact: undefined }));
                        }}
                        placeholder="(11) 99999-9999 ou nome@empresa.com"
                        aria-invalid={Boolean(errors.contact)}
                        className="w-full px-4 py-3 min-h-[44px] rounded-lg bg-white border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 transition-colors"
                      />
                      {errors.contact && (
                        <p className="mt-1.5 text-xs font-medium text-red-700" role="alert">
                          {errors.contact}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-objective"
                      className="block text-sm font-medium text-[#070B12] mb-1.5"
                    >
                      O que você espera do novo site? *
                    </label>
                    <textarea
                      id="contact-objective"
                      rows={4}
                      value={objective}
                      onChange={(e) => {
                        setObjective(e.target.value);
                        if (errors.objective) setErrors((prev) => ({ ...prev, objective: undefined }));
                      }}
                      placeholder="Ex.: Preciso de um site institucional rápido para receber contatos de clientes vindos do Google."
                      aria-invalid={Boolean(errors.objective)}
                      className="w-full px-4 py-3 rounded-lg bg-white border border-slate-300 text-sm text-[#070B12] placeholder:text-slate-400 focus:outline-none focus:border-[#0B1F3A] focus:ring-2 focus:ring-[#0B1F3A]/15 transition-colors resize-y"
                    />
                    {errors.objective && (
                      <p className="mt-1.5 text-xs font-medium text-red-700" role="alert">
                        {errors.objective}
                      </p>
                    )}
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <button
                      type="submit"
                      className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 min-h-[48px] rounded-lg bg-[#0B1F3A] text-white text-sm sm:text-base font-semibold hover:bg-[#112D54] active:scale-[0.99] transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0B1F3A]"
                    >
                      <WhatsAppIcon className="w-4 h-4 shrink-0" />
                      <span>Solicitar orçamento no WhatsApp</span>
                    </button>

                    <span className="text-xs text-slate-600">
                      Resposta direta em até 24h úteis
                    </span>
                  </div>
                </form>
              ) : (
                <div className="space-y-6" role="status" aria-live="polite">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#0B1F3A] text-white flex items-center justify-center shrink-0">
                      <Check className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-display text-xl font-bold text-[#070B12]">
                        Resumo pronto para envio no WhatsApp
                      </h3>
                      <p className="text-sm text-slate-600 mt-1">
                        Seu briefing foi organizado abaixo. Clique para abrir o WhatsApp com a mensagem preenchida ou copie o texto.
                      </p>
                    </div>
                  </div>

                  <pre className="bg-white border border-slate-200 rounded-xl p-4 text-xs sm:text-sm text-[#070B12] font-sans whitespace-pre-wrap leading-relaxed">
                    {whatsappMessage}
                  </pre>

                  <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3">
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[44px] rounded-lg bg-[#0B1F3A] text-white text-sm font-semibold hover:bg-[#112D54] transition-colors whitespace-nowrap"
                    >
                      <WhatsAppIcon className="w-4 h-4 shrink-0" />
                      <span>Solicitar orçamento no WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={handleCopy}
                      className="inline-flex items-center justify-center gap-2 px-4 py-3 min-h-[44px] rounded-lg bg-white border border-slate-300 text-sm font-medium text-[#070B12] hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {copied ? <Check className="w-4 h-4 text-[#0B1F3A]" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? 'Resumo copiado' : 'Copiar briefing'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleReset}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 min-h-[44px] text-sm font-medium text-slate-600 hover:text-[#070B12] cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Editar dados</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
