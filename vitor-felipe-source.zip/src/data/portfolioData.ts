export type ProjectCategory = 'Todos' | 'Institucional' | 'Landing Page' | 'Portfólio';

export interface ServiceItem {
  number: string;
  id: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  timeline: string;
  featured?: boolean;
}

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'Todos'>;
  year: string;
  outcome: string;
  summary: string;
  challenge: string;
  solution: string;
  deliverables: string[];
  metrics: { label: string; value: string }[];
  image: string;
  imageAlt: string;
  featured?: boolean;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  name: string;
  role: string;
  company: string;
  outcome: string;
}

export interface DifferentialItem {
  number: string;
  title: string;
  description: string;
}

export const WHATSAPP_NUMBER = '5541997007292';
export const WHATSAPP_DISPLAY = '(41) 99700-7292';

export const HERO_IMAGE = {
  src: '/src/assets/images/hero_workspace_showcase_1795454149685.jpg',
  alt: 'Mesa minimalista com notebook exibindo projeto de site moderno desenvolvido por Vitor Felipe',
};

export const ABOUT_IMAGE = {
  src: '/src/assets/images/about_vitor_portrait_1795454150179.jpg',
  alt: 'Retrato de Vitor Felipe trabalhando em projetos digitais em estúdio minimalista',
};

export const HERO_METRICS = [
  { value: '+95', label: 'Nota média no PageSpeed Mobile' },
  { value: '< 1,2s', label: 'Tempo de carregamento inicial' },
  { value: '100%', label: 'Layout autoral sem templates prontos' },
  { value: '24h', label: 'Retorno do seu briefing no WhatsApp' },
];

export const DIFFERENTIALS: DifferentialItem[] = [
  {
    number: '01.',
    title: 'Foco em geração de orçamentos',
    description:
      'Cada dobra, título e chamada para ação é organizada para conduzir o visitante até o contato no WhatsApp sem distrações.',
  },
  {
    number: '02.',
    title: 'Velocidade real no celular',
    description:
      'Mais de 80% do tráfego local e de anúncios vem do smartphone. Código enxuto garante abertura instantânea mesmo em 4G.',
  },
  {
    number: '03.',
    title: 'Atendimento direto comigo',
    description:
      'Sem intermediários ou repasse de demandas. Você alinha estratégia, design e ajustes diretamente com quem projeta e programa.',
  },
  {
    number: '04.',
    title: 'Pronto para Google e anúncios',
    description:
      'Estrutura semântica, SEO técnico de base, metatags e rastreamento configurados para campanhas no Google Ads e Meta Ads.',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    number: '01.',
    id: 'site-institucional',
    title: 'Sites Institucionais de Autoridade',
    subtitle: 'Para empresas e profissionais que precisam transmitir confiança imediata',
    description:
      'Arquitetura completa de múltiplas seções ou páginas para apresentar serviços, diferenciais, provas sociais e captar leads qualificados.',
    deliverables: [
      'Design exclusivo alinhado à sua marca',
      'Copywriting estratégico de apresentação',
      'Integração direta com WhatsApp e formulários',
    ],
    timeline: 'Entrega em 12 a 18 dias úteis',
    featured: true,
  },
  {
    number: '02.',
    id: 'landing-page',
    title: 'Landing Pages de Alta Conversão',
    subtitle: 'Para campanhas de tráfego pago e captação direta',
    description:
      'Página única focada em um serviço ou oferta específica, estruturada para reduzir o custo por clique e aumentar pedidos de orçamento.',
    deliverables: [
      'Estrutura persuasiva orientada à oferta',
      'Carregamento ultrarrápido para Google e Meta Ads',
      'Botões de WhatsApp com mensagem pré-preenchida',
    ],
    timeline: 'Entrega em 5 a 8 dias úteis',
  },
  {
    number: '03.',
    id: 'redesenho-otimizacao',
    title: 'Redesenho & Performance',
    subtitle: 'Para sites lentos, desatualizados ou que não geram contatos',
    description:
      'Reconstrução visual e técnica de páginas existentes para corrigir falhas no celular, elevar a nota de velocidade e melhorar a conversão.',
    deliverables: [
      'Auditoria de usabilidade e pontos de fuga',
      'Nova interface responsiva em padrão atual',
      'Otimização de imagens, fontes e SEO técnico',
    ],
    timeline: 'Entrega em 7 a 12 dias úteis',
  },
  {
    number: '04.',
    id: 'portfolio-catalogo',
    title: 'Portfólios & Catálogos Digitais',
    subtitle: 'Para escritórios, consultorias, clínicas e marcas autorais',
    description:
      'Exposição editorial de projetos, tratamentos ou linhas de produto com filtros simples e solicitação imediata de orçamento item a item.',
    deliverables: [
      'Galeria responsiva com visualização detalhada',
      'Organização por categorias sem poluição visual',
      'Encaminhamento direto para atendimento comercial',
    ],
    timeline: 'Entrega em 10 a 15 dias úteis',
  },
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'stratos-advisory',
    title: 'Stratos Consultoria Empresarial',
    client: 'Stratos Advisory',
    category: 'Institucional',
    year: '2026',
    outcome: '+140% de pedidos de orçamento em 90 dias',
    summary:
      'Site institucional B2B projetado para posicionar uma consultoria financeira diante de médias empresas e direcionar reuniões via WhatsApp.',
    challenge:
      'O site anterior era um template genérico lento, com textos longos e nenhum caminho claro para o decisor solicitar uma conversa.',
    solution:
      'Reorganizamos a proposta de valor na primeira dobra, separamos os serviços por momento da empresa e inserimos provas numéricas ao lado das chamadas para orçamento.',
    deliverables: ['Arquitetura de informação', 'Design UI sob medida', 'Desenvolvimento front-end', 'SEO técnico'],
    metrics: [
      { label: 'Orçamentos qualificados', value: '+140%' },
      { label: 'Nota PageSpeed', value: '98 / 100' },
      { label: 'Carregamento mobile', value: '0,9s' },
    ],
    image: '/src/assets/images/project_fintech_site_1795454150791.jpg',
    imageAlt: 'Monitor exibindo o site institucional da Stratos Consultoria em azul marinho e branco',
    featured: true,
  },
  {
    id: 'aethera-clinica',
    title: 'Clínica Aethera Saúde Integrada',
    client: 'Aethera Saúde',
    category: 'Landing Page',
    year: '2026',
    outcome: '3,4x mais agendamentos vindos de anúncios',
    summary:
      'Landing page focada em atendimentos particulares com apresentação serena do espaço clínico e agendamento imediato no WhatsApp.',
    challenge:
      'Os anúncios geravam cliques, mas os pacientes abandonavam a página por falta de clareza sobre especialidades e demora no carregamento.',
    solution:
      'Criamos uma página leve com hierarquia limpa, apresentação direta da equipe médica e botões contextuais que já abrem o WhatsApp com a especialidade selecionada.',
    deliverables: ['Landing page responsiva', 'Copywriting médico ético', 'Integração WhatsApp'],
    metrics: [
      { label: 'Taxa de conversão', value: '8,6%' },
      { label: 'Redução no CPC efetivo', value: '-32%' },
      { label: 'Nota PageSpeed', value: '97 / 100' },
    ],
    image: '/src/assets/images/project_clinic_site_1795454152128.jpg',
    imageAlt: 'Notebook sobre pedra natural exibindo landing page limpa da Clínica Aethera',
  },
  {
    id: 'monolith-arquitetura',
    title: 'Monolith Arquitetura & Interiores',
    client: 'Estúdio Monolith',
    category: 'Portfólio',
    year: '2025',
    outcome: 'Novo posicionamento para projetos residenciais de alto padrão',
    summary:
      'Portfólio editorial minimalista em preto, branco e azul profundo com foco total nas fotografias dos projetos e leitura fluida no celular.',
    challenge:
      'Um portfólio pesado cheio de animações travava em smartphones e não refletia o rigor arquitetônico do escritório.',
    solution:
      'Desenvolvemos uma grade editorial enxuta com carregamento progressivo de imagens e ficha técnica objetiva em cada projeto.',
    deliverables: ['Direção de arte digital', 'Portfólio com lightbox', 'Otimização de mídia'],
    metrics: [
      { label: 'Tempo médio na página', value: '3m 18s' },
      { label: 'Propostas recebidas', value: '+85%' },
      { label: 'Nota PageSpeed', value: '96 / 100' },
    ],
    image: '/src/assets/images/project_architecture_site_1795454150758.jpg',
    imageAlt: 'Notebook e smartphone exibindo o portfólio responsivo da Monolith Arquitetura',
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote:
      'Nosso antigo site parecia amador e quase ninguém preenchia o formulário. Depois do novo site com o Vitor Felipe, os clientes já chegam no WhatsApp entendendo o valor da consultoria.',
    name: 'Rafael Mendonça',
    role: 'Sócio-diretor',
    company: 'Stratos Advisory',
    outcome: '+140% de contatos comerciais em 3 meses',
  },
  {
    id: 't2',
    quote:
      'Eu investia no Google Ads todo mês, mas o retorno era baixo. Bastou publicar a nova landing page pensada para o celular para nossa agenda de avaliações dobrar já nas primeiras semanas.',
    name: 'Dra. Camila Vasconcelos',
    role: 'Diretora Clínica',
    company: 'Aethera Saúde Integrada',
    outcome: '3,4x mais agendamentos pelo WhatsApp',
  },
  {
    id: 't3',
    quote:
      'O processo foi direto e sem enrolação. O Vitor Felipe traduziu o estilo minimalista do nosso escritório em um site rápido, limpo e muito fácil de navegar tanto no computador quanto no telefone.',
    name: 'Henrique Alencar',
    role: 'Arquiteto Titular',
    company: 'Estúdio Monolith',
    outcome: '+85% em solicitações de projeto',
  },
];

export interface WhatsAppBriefingPayload {
  name?: string;
  business?: string;
  service?: string;
  objective?: string;
  contact?: string;
}

export function buildWhatsAppMessage(payload: WhatsAppBriefingPayload): string {
  const lines = [
    'Olá Vitor Felipe! Gostaria de solicitar um orçamento para criação de site.',
  ];

  if (payload.name?.trim()) {
    lines.push(`• Nome: ${payload.name.trim()}`);
  }
  if (payload.business?.trim()) {
    lines.push(`• Empresa / Projeto: ${payload.business.trim()}`);
  }
  if (payload.service?.trim()) {
    lines.push(`• Tipo de projeto: ${payload.service.trim()}`);
  }
  if (payload.objective?.trim()) {
    lines.push(`• Objetivo principal: ${payload.objective.trim()}`);
  }
  if (payload.contact?.trim()) {
    lines.push(`• E-mail / Retorno: ${payload.contact.trim()}`);
  }

  return lines.join('\n');
}

export function buildWhatsAppUrl(payload: WhatsAppBriefingPayload): string {
  const message = buildWhatsAppMessage(payload);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
